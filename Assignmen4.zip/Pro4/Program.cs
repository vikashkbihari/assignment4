﻿using System;
using System .Collections.Generic;
namespace Pro4
{
    class Program
    {
        static void Main(string[] args)
        {   PrDetailFill obj1 = new PrDetailFill();
            List<PrDetail> pD =new List<PrDetail>();
            pD=obj1.Pdf();

            Console.WriteLine("Hello World!");
            PrGroupFill obj =new PrGroupFill();
            List<PrGroup> pG= new List<PrGroup>();
            pG=obj.Pgf();
            int k=100;
            //Display the available item
            foreach (PrGroup item1 in pG)
            {  
              Console.WriteLine("Items availabe in {0} are :-",item1.GrName);
                   foreach (PrDetail item in pD)
                   {   
                      if(item.GrId==k)
                      {
                         Console.WriteLine("----- {0}-----",item.PrName);
                      }
                       
                   }
                   k=k+100;
            }  
            // Search the Item or know more
                  Console.WriteLine("Do you want to Sort the Product ?");
            Console.WriteLine("Enter-1 To sort the product on Rate Low to high ");
            Console.WriteLine("Enter-2 To sort the product on Rate High to Low");
            int num=int.Parse(Console.ReadLine());
            switch(num)
             { case 1 :
                  Console.WriteLine("-----Sorted Product [L-H]-----");
                   pD.Sort();
                  foreach (PrDetail item in pD)
                 {
                     Console.WriteLine(" {0},rate--{1} per Kg",item.PrName,item.Rate);
                 }
               Console.WriteLine(" -----------------------");
               break;
               case 2 :
                  Console.WriteLine("-----Sorted Product [H-L]-----");
                  pD.Sort();
                  pD.Reverse();
                  foreach (PrDetail item in pD)
                 {
                     Console.WriteLine(" {0},rate--{1} per Kg",item.PrName,item.Rate);
                 }
                  Console.WriteLine(" -----------------------");
                 break;
               default:
                  Console.WriteLine(" You have not sorted the product ");
                 break;
            }
           

             string str3="",str4="";
        try
        {
            
        int flag=0;
         do{
            Console.WriteLine(" Search the product ");

            Console.WriteLine(" To Know more about Products ,pls Enter the product Name");
              string str=Console.ReadLine();
              
             foreach (PrDetail item2 in pD)
             {   if(item2.PrName==str|| (item2.PrName[0]==str[0])&& item2.PrName[1]==str[1]){
                 Console.WriteLine(" Available items ---{0}",item2.PrName);
                 Console.WriteLine("Description--{0}",item2.Des);
                 Console.WriteLine("Rate {0} rupees per kg.",item2.Rate);
                 Console.WriteLine(" -------------------------------------------------------");
                 flag=1;
                }                
                
             }
             if(flag==0)
             {
                 Console.WriteLine("Sorry you have entered a wrong product");
                 Console.WriteLine("--------------------------------------");
                 
             }
                 Console.WriteLine("Do u Want to search More Enter Yes:- ");
                 Console.WriteLine("To Exit Enter No ");
                  str3=Console.ReadLine();
                  str4=str3.ToUpper();

             }while(str4=="YES");
              }
              
                 
        catch (System.Exception)
        {
            
         Console.WriteLine("sorry something is wrong-");
          
        }    
        }
    }
}

