using System;
using System.Collections.Generic;
namespace Pro4
{
   public class PrGroup
   {
     public int GrId;
     public string GrName;
   }
  //end of PGroup
    public class PrGroupFill
       {
           public List<PrGroup> Pgf()
         {
            PrGroup Pg1 =new PrGroup()
           {
           GrId=100,
           GrName="Diary"
           };
           PrGroup Pg2 =new PrGroup()
           {
           GrId=200,
           GrName="Choclate"
            };
           PrGroup Pg3 =new PrGroup()
          {
           GrId=300,
           GrName="Sweets"
          };
    
          List<PrGroup> PgList=new List<PrGroup>(3);
            PgList.Add (Pg1);
            PgList.Add (Pg2);
            PgList.Add(Pg3);
           return PgList;
         }
       }
}
