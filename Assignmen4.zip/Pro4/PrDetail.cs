using System;
using System.Collections.Generic;
namespace Pro4
{
   public class PrDetail :IComparable<PrDetail>
   {
     public int PrId;
     public int GrId;
     public string PrName;
     public string Des;
     public int Rate;
     public int CompareTo(PrDetail other)
     {
         return this.Rate.CompareTo(other.Rate);
     }
     
      }
  //end of PGroup
    public class PrDetailFill 
       {
           public List<PrDetail> Pdf()
         {    
           PrDetail Pd1 =new PrDetail()
           {   GrId=100,
              PrId=101,
              PrName="cheese Amul",
              Des="150 gm amul cheese",
              Rate=200

           };
            PrDetail Pd2 =new PrDetail()
           {  GrId=100,
              PrId=102,
              PrName="cheese britania ",
              Des="150 gm brit cheese",
              Rate=220

           };
                 
            PrDetail Pd3 =new PrDetail()
           {  GrId=300,
              PrId=301,
              PrName="sweet Kyo ",
              Des="150 gm Kyo sweet",
              Rate=300

           };
            PrDetail Pd4 =new PrDetail()
           {  GrId=300,
              PrId=302,
              PrName="sweet gy ",
              Des="150 gm amul cheese",
              Rate=350

           };
            PrDetail Pd5 =new PrDetail()
           {  GrId=200,
              PrId=201,
              PrName="kitkat",
              Des="150 gm kitkat",
              Rate=600

           };
            PrDetail Pd6 =new PrDetail()
           {  GrId=200,
              PrId=202,
              PrName="alpenleve ",
              Des="150 gm amul cheese",
              Rate=520

           };
    
          List<PrDetail> PdList=new List<PrDetail>(6);
            PdList.Add (Pd1);
             PdList.Add (Pd2);
              PdList.Add (Pd3);
               PdList.Add (Pd4);
                PdList.Add (Pd5);
                 PdList.Add (Pd6);
           List<PrDetail> pdl =new List<PrDetail>(6);
           pdl.Add (Pd1);
             pdl.Add (Pd2);
              pdl.Add (Pd3);
               pdl.Add (Pd4);
                pdl.Add (Pd5);
                 pdl.Add (Pd6);     
                 return PdList;
         }
        
       }

}
